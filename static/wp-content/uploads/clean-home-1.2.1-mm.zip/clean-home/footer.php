
	<div id="footer">
    <p><?php wp_footer() ?></p>
	</div>

</div>

<!-- Can put web stats code here -->

</body>

</html>